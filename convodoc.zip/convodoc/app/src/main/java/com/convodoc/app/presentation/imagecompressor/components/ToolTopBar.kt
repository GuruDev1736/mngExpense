package com.convodoc.app.presentation.imagecompressor.components


import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ToolTopBar(

    title: String,

    onBack: () -> Unit

) {

    CenterAlignedTopAppBar(

        title = {

            Text(title)

        },

        navigationIcon = {

            IconButton(

                onClick = onBack

            ) {

                Icon(

                    Icons.AutoMirrored.Rounded.ArrowBack,

                    null

                )

            }

        }

    )

}